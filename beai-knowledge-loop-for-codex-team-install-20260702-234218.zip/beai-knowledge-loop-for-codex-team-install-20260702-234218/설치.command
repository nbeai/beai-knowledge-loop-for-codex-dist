#!/bin/zsh
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_DIR="$ROOT_DIR/plugins/beai-knowledge-loop-for-codex"
PLUGIN_JSON="$PLUGIN_DIR/.codex-plugin/plugin.json"
MCP_JSON="$PLUGIN_DIR/.mcp.json"
MCP_SERVER="$PLUGIN_DIR/mcp/beai-knowledge-loop-mcp.js"
MARKETPLACE_JSON="$ROOT_DIR/.agents/plugins/marketplace.json"

echo "BEAI Knowledge Loop for Codex team installer"
echo "Package root: $ROOT_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is required but was not found on PATH."
  exit 1
fi

if ! command -v codex >/dev/null 2>&1; then
  echo "ERROR: Codex CLI is required but was not found on PATH."
  exit 1
fi

if [[ ! -f "$PLUGIN_JSON" ]]; then
  echo "ERROR: Missing plugin manifest: $PLUGIN_JSON"
  exit 1
fi

if [[ ! -f "$MCP_JSON" ]]; then
  echo "ERROR: Missing MCP config: $MCP_JSON"
  exit 1
fi

if [[ ! -f "$MCP_SERVER" ]]; then
  echo "ERROR: Missing MCP server: $MCP_SERVER"
  exit 1
fi

if [[ ! -f "$MARKETPLACE_JSON" ]]; then
  echo "ERROR: Missing marketplace file: $MARKETPLACE_JSON"
  exit 1
fi

node "$ROOT_DIR/tools/patch-mcp-paths.mjs" "$PLUGIN_JSON" "$MCP_JSON" "$MCP_SERVER"
node --check "$MCP_SERVER"
node "$PLUGIN_DIR/scripts/check-package-hygiene.js" "$ROOT_DIR"
node "$PLUGIN_DIR/scripts/verify-plugin-install-root.js" "$PLUGIN_DIR"

codex plugin marketplace add "$ROOT_DIR"

echo ""
echo "Installed marketplace root:"
echo "$ROOT_DIR"
echo ""
echo "Next:"
echo "1. Restart the Codex app completely."
echo "2. Open Plugins and install BEAI Knowledge Loop for Codex from the BEAI Team Local marketplace."
echo "3. Start a new Codex thread and ask it to use BEAI Knowledge Loop."
