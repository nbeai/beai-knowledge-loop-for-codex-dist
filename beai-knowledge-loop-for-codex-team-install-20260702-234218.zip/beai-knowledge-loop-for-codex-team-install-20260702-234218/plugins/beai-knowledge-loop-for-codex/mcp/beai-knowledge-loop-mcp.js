#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";

const SERVER_VERSION = "0.1.0";
const SERVER_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DEFAULT_STORE_DIR = ".codex/knowledge-loop";
const OUTPUT_CLASSES = [
  "observed_fact",
  "user_decision",
  "assistant_judgment",
  "inferred_pattern",
  "trap",
  "knowledge_candidate",
  "development_candidate",
  "product_candidate",
  "evidence",
  "next_action",
  "rejected_scope"
];

const CLASS_WEIGHTS = {
  user_decision: 8,
  trap: 7,
  evidence: 6,
  observed_fact: 5,
  development_candidate: 4,
  product_candidate: 4,
  knowledge_candidate: 4,
  inferred_pattern: 3,
  assistant_judgment: 2,
  next_action: 2,
  rejected_scope: 1
};

const REVIEW_STATES = ["needs-review", "approved", "stale", "superseded", "rejected"];
const DEFAULT_EXCLUDED_REVIEW_STATES = ["rejected"];

const REVIEW_STATE_WEIGHTS = {
  approved: 6,
  "needs-review": 0,
  stale: -45,
  superseded: -55,
  rejected: -100
};

function nowIso() {
  return new Date().toISOString();
}

function asArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function resolveWorkspace(args = {}) {
  const workspace = path.resolve(args.workspace || process.env.BEAI_KNOWLEDGE_LOOP_WORKSPACE || process.cwd());
  assertSafeWorkspace(workspace);
  return workspace;
}

function storeRoot(workspace) {
  const root = path.resolve(workspace, process.env.BEAI_KNOWLEDGE_LOOP_STORE || DEFAULT_STORE_DIR);
  assertInside(workspace, root, "store root");
  return root;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function assertSafeWorkspace(workspace) {
  const parsed = path.parse(workspace);
  const home = process.env.HOME ? path.resolve(process.env.HOME) : null;
  if (workspace === parsed.root) {
    throw new Error("Unsafe workspace: filesystem root is not allowed.");
  }
  if (home && workspace === home) {
    throw new Error("Unsafe workspace: home directory root is not allowed.");
  }
}

function isInside(parent, child) {
  const relative = path.relative(parent, child);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function assertInside(parent, child, label) {
  if (!isInside(parent, child)) {
    throw new Error(`Unsafe ${label}: path escapes ${parent}`);
  }
}

function safeFileStem(value, fallback = "record") {
  const raw = String(value || "").trim();
  if (!raw) return fallback;
  if (raw === "." || raw === ".." || raw.includes("/") || raw.includes("\\") || raw.includes("..")) {
    throw new Error("Unsafe id: path separators and traversal segments are not allowed.");
  }
  const stem = raw
    .replace(/[^a-zA-Z0-9가-힣._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
  if (!stem || stem === "." || stem === "..") {
    throw new Error("Unsafe id: unable to create a safe local filename.");
  }
  return stem;
}

function safeFilePath(baseDir, stem, suffix, label) {
  const filePath = path.join(baseDir, `${safeFileStem(stem)}${suffix}`);
  assertInside(baseDir, filePath, label);
  return filePath;
}

function readJsonIfValid(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return null;
  }
}

function listJsonFiles(dirPath) {
  if (!fs.existsSync(dirPath)) return [];
  return fs.readdirSync(dirPath)
    .filter((entry) => entry.endsWith(".json"))
    .map((entry) => path.join(dirPath, entry))
    .sort();
}

function reviewStatePath(workspace) {
  return path.join(storeRoot(workspace), "review-queue", "review-states.json");
}

function readReviewStates(workspace) {
  const statePath = reviewStatePath(workspace);
  const states = readJsonIfValid(statePath);
  if (states?.schema === "beai.knowledge_loop.review_states.v0_3" && states.records && typeof states.records === "object") {
    return states;
  }
  return {
    schema: "beai.knowledge_loop.review_states.v0_3",
    updated_at: null,
    records: {},
    history: []
  };
}

function writeReviewStates(workspace, states) {
  const statePath = reviewStatePath(workspace);
  ensureDir(path.dirname(statePath));
  fs.writeFileSync(statePath, `${JSON.stringify(states, null, 2)}\n`, "utf8");
  return statePath;
}

function normalizeReviewState(value) {
  const state = String(value || "needs-review").trim().toLowerCase();
  if (!REVIEW_STATES.includes(state)) {
    throw new Error(`Invalid review_state: ${state}. Allowed: ${REVIEW_STATES.join(", ")}`);
  }
  return state;
}

function embeddedReviewState(record) {
  const reviewText = JSON.stringify(record.review_status || {}).toLowerCase();
  if (reviewText.includes("approved")) return "approved";
  if (reviewText.includes("rejected")) return "rejected";
  if (reviewText.includes("superseded")) return "superseded";
  if (reviewText.includes("stale")) return "stale";
  return "needs-review";
}

function applyReviewState(record, workspace, states = readReviewStates(workspace)) {
  const sidecar = states.records?.[record.id] || null;
  const state = normalizeReviewState(sidecar?.state || record.raw?.review_state || record.raw?.review_status?.state || embeddedReviewState(record));
  const reviewState = {
    state,
    source: sidecar ? "sidecar" : "embedded-or-default",
    reason: sidecar?.reason || "",
    supersedes: sidecar?.supersedes || null,
    superseded_by: sidecar?.superseded_by || null,
    updated_at: sidecar?.updated_at || null,
    reviewer: sidecar?.reviewer || null
  };
  return {
    ...record,
    review_state: reviewState,
    review_status: {
      ...record.review_status,
      state: reviewState.state,
      sidecar: sidecar || undefined
    }
  };
}

function textBlob(record) {
  return [
    record.title,
    record.summary,
    record.source_reference,
    ...OUTPUT_CLASSES.flatMap((key) => asArray(record[key]).map((item) => typeof item === "string" ? item : item?.text || item?.summary || item?.title || ""))
  ].filter(Boolean).join("\n").toLowerCase();
}

function normalizeRecord(raw, filePath) {
  const source = raw.source_record || raw;
  const classes = raw.output_classes || raw.classes || {};
  const merged = { ...source, ...classes };
  return {
    id: source.id || raw.id || path.basename(filePath, ".json"),
    title: source.title || raw.title || "Untitled knowledge record",
    project: source.project || raw.project || "unknown",
    summary: raw.first_pass_note?.summary || raw.summary || "",
    source_reference: source.source_reference || raw.source_reference || filePath,
    path: filePath,
    review_status: raw.review_status || {},
    safety: raw.safety || {},
    classes: Object.fromEntries(OUTPUT_CLASSES.map((key) => [key, asArray(merged[key] || raw[key])])),
    raw
  };
}

function loadRecords(workspace) {
  const root = storeRoot(workspace);
  const candidates = [
    path.join(root, "records"),
    path.join(root, "generated"),
    path.join(root, "candidates"),
    path.join(root, "drafts")
  ];
  const records = [];
  const states = readReviewStates(workspace);
  for (const dirPath of candidates) {
    for (const filePath of listJsonFiles(dirPath)) {
      const raw = readJsonIfValid(filePath);
      if (!raw) continue;
      records.push(applyReviewState(normalizeRecord(raw, filePath), workspace, states));
    }
  }
  return records;
}

function tokenize(value) {
  return String(value || "")
    .toLowerCase()
    .match(/[a-z0-9가-힣_-]{2,}/g) || [];
}

function itemText(item) {
  return typeof item === "string" ? item : item?.text || item?.summary || item?.title || "";
}

function recordClassCounts(record) {
  return Object.fromEntries(OUTPUT_CLASSES.map((key) => [key, asArray(record.classes?.[key]).length]));
}

function indexTerms(record) {
  const counts = new Map();
  const add = (text, weight = 1) => {
    for (const token of tokenize(text)) {
      counts.set(token, (counts.get(token) || 0) + weight);
    }
  };

  add(record.title, 5);
  add(record.project, 3);
  add(record.summary, 3);
  add(record.source_reference, 2);
  for (const key of OUTPUT_CLASSES) {
    for (const item of asArray(record.classes?.[key])) {
      add(itemText(item), CLASS_WEIGHTS[key] || 1);
    }
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, 40)
    .map(([term, weight]) => ({ term, weight }));
}

function buildIndex(args = {}) {
  const workspace = resolveWorkspace(args);
  const root = storeRoot(workspace);
  const records = loadRecords(workspace);
  const index = {
    schema: "beai.knowledge_loop.codex_index.v0_1",
    generated_at: nowIso(),
    workspace,
    store: root,
    record_count: records.length,
    records: records.map((record) => ({
      id: record.id,
      title: record.title,
      project: record.project,
      summary: record.summary,
      source_reference: record.source_reference,
      path: record.path,
      class_counts: recordClassCounts(record),
      terms: indexTerms(record),
      review_state: record.review_state,
      review_status: record.review_status,
      safety: record.safety
    })),
    safety: safetyBoundary()
  };

  if (args.write === true) {
    ensureDir(root);
    fs.writeFileSync(path.join(root, "index.json"), `${JSON.stringify(index, null, 2)}\n`, "utf8");
  }

  return index;
}

function readIndex(workspace) {
  const indexPath = path.join(storeRoot(workspace), "index.json");
  const index = readJsonIfValid(indexPath);
  if (index?.schema === "beai.knowledge_loop.codex_index.v0_1") return index;
  return null;
}

function scoreRecord(record, terms) {
  if (!terms.length) return { total: 0, reasons: [] };
  let total = 0;
  const reasons = [];
  const title = String(record.title || "").toLowerCase();
  const summary = String(record.summary || "").toLowerCase();
  const queryPhrase = terms.join(" ");
  const fullText = [
    title,
    summary,
    record.project,
    record.source_reference,
    ...OUTPUT_CLASSES.flatMap((key) => asArray(record.classes?.[key]).map(itemText))
  ].join("\n").toLowerCase();

  if (queryPhrase.length >= 4 && fullText.includes(queryPhrase)) {
    total += 20;
    reasons.push(`phrase:${queryPhrase}`);
  }

  let matchedTerms = 0;

  for (const term of terms) {
    let matched = false;
    if (title.includes(term)) {
      total += 12;
      reasons.push(`title:${term}`);
      matched = true;
    }
    if (summary.includes(term)) {
      total += 5;
      reasons.push(`summary:${term}`);
      matched = true;
    }
    for (const key of OUTPUT_CLASSES) {
      for (const item of asArray(record.classes?.[key])) {
        if (itemText(item).toLowerCase().includes(term)) {
          const weight = CLASS_WEIGHTS[key] || 1;
          total += weight;
          reasons.push(`${key}:${term}`);
          matched = true;
        }
      }
    }
    if (matched) matchedTerms += 1;
  }

  const coverage = matchedTerms / terms.length;
  if (coverage === 1) {
    total += 12;
    reasons.push("coverage:all-terms");
  } else if (coverage >= 0.6) {
    total += 5;
    reasons.push("coverage:partial");
  }

  const hasReviewedSignal = JSON.stringify(record.review_status || {}).includes("reviewed");
  const reviewState = record.review_state?.state || "needs-review";
  const hasSafetyBlock = record.safety?.memory_write_allowed === true || record.safety?.external_send_allowed === true;
  const reviewWeight = REVIEW_STATE_WEIGHTS[reviewState] || 0;
  if (reviewWeight !== 0) {
    total += reviewWeight;
    reasons.push(`review-state:${reviewState}`);
  }
  if (hasReviewedSignal) total += 2;
  if (hasSafetyBlock) total -= 10;
  return { total, reasons: [...new Set(reasons)].slice(0, 10) };
}

function stateSet(values, fallback = []) {
  const source = values === undefined ? fallback : values;
  return new Set(asArray(source).map(normalizeReviewState));
}

function searchKnowledge(args = {}) {
  const workspace = resolveWorkspace(args);
  const query = String(args.query || "").trim().toLowerCase();
  const limit = Math.max(1, Math.min(Number(args.limit || 8), 25));
  const records = loadRecords(workspace);
  const terms = tokenize(query);
  const includeStates = args.include_states ? stateSet(args.include_states) : null;
  const excludeStates = stateSet(args.exclude_states, DEFAULT_EXCLUDED_REVIEW_STATES);
  const matches = records.filter((record) => {
    const state = record.review_state?.state || "needs-review";
    if (includeStates && !includeStates.has(state)) return false;
    return !excludeStates.has(state);
  }).map((record) => {
    const score = scoreRecord(record, terms);
    return { record, score: score.total, reasons: score.reasons };
  }).filter((item) => terms.length === 0 || item.score > 0 || Boolean(includeStates))
    .sort((a, b) => b.score - a.score || a.record.title.localeCompare(b.record.title))
    .slice(0, limit)
    .map(({ record, score, reasons }) => ({
      id: record.id,
      title: record.title,
      project: record.project,
      source_reference: record.source_reference,
      path: record.path,
      score,
      reasons,
      summary: record.summary,
      class_counts: recordClassCounts(record),
      review_state: record.review_state,
      review_status: record.review_status,
      safety: record.safety
    }));

  return {
    workspace,
    store: storeRoot(workspace),
    query,
    index_available: Boolean(readIndex(workspace)),
    included_review_states: includeStates ? [...includeStates] : "all except excluded",
    excluded_review_states: [...excludeStates],
    count: matches.length,
    results: matches,
    boundary: "read-only search; no memory write or promotion"
  };
}

function getBrief(args = {}) {
  const workspace = resolveWorkspace(args);
  const id = String(args.id || "").trim();
  if (!id) throw new Error("id is required");
  const record = loadRecords(workspace).find((item) => item.id === id || item.path === id);
  if (!record) {
    return { found: false, id, workspace, message: "No matching knowledge record found." };
  }
  return {
    found: true,
    id: record.id,
    title: record.title,
    source_reference: record.source_reference,
    summary: record.summary,
    observed_facts: record.classes.observed_fact,
    decisions: record.classes.user_decision,
    inferred_patterns: record.classes.inferred_pattern,
    traps: record.classes.trap,
    knowledge_candidates: record.classes.knowledge_candidate,
    development_candidates: record.classes.development_candidate,
    product_candidates: record.classes.product_candidate,
    evidence: record.classes.evidence,
    next_actions: record.classes.next_action,
    review_status: record.review_status,
    review_state: record.review_state,
    safety: record.safety,
    boundary: "brief only; no durable memory update"
  };
}

function setReviewState(args = {}) {
  const workspace = resolveWorkspace(args);
  const id = String(args.id || "").trim();
  if (!id) throw new Error("id is required");
  const state = normalizeReviewState(args.state);
  const record = loadRecords(workspace).find((item) => item.id === id || item.path === id);
  if (!record) {
    return { found: false, id, workspace, message: "No matching knowledge record found." };
  }

  const states = readReviewStates(workspace);
  const previous = states.records[id] || null;
  const entry = {
    state,
    reason: args.reason || "",
    supersedes: args.supersedes || null,
    superseded_by: args.superseded_by || null,
    reviewer: args.reviewer || "human-review-required",
    updated_at: nowIso(),
    record_path: record.path
  };
  states.records[id] = entry;
  states.updated_at = entry.updated_at;
  states.history = asArray(states.history);
  states.history.push({
    at: entry.updated_at,
    id,
    from: previous?.state || record.review_state?.state || "needs-review",
    to: state,
    reason: entry.reason,
    reviewer: entry.reviewer
  });
  const pathWritten = writeReviewStates(workspace, states);
  return {
    status: "review-state-set",
    id,
    state,
    previous_state: previous?.state || record.review_state?.state || "needs-review",
    path: pathWritten,
    boundary: "review state sidecar written locally; original record and durable memory were not mutated"
  };
}

function normalizeDraftItems(values, className, sourceReference) {
  return asArray(values).map((item) => {
    if (typeof item === "string") {
      return {
        class: className,
        text: item,
        source_reference: sourceReference,
        review_status: "needs-review"
      };
    }
    return {
      class: item.class || className,
      text: item.text || item.summary || item.title || "",
      source_reference: item.source_reference || sourceReference,
      review_status: item.review_status || "needs-review"
    };
  }).filter((item) => item.text);
}

function captureDraft(args = {}) {
  const workspace = resolveWorkspace(args);
  const root = storeRoot(workspace);
  const draftDir = path.join(root, "drafts");
  ensureDir(draftDir);

  const sourceReference = args.source_reference || "manual-codex-session";
  const title = args.title || "Codex knowledge draft";
  const id = args.id || `${title.toLowerCase().replace(/[^a-z0-9가-힣]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "draft"}-${Date.now()}`;
  safeFileStem(id);
  const outputClasses = {};
  for (const key of OUTPUT_CLASSES) {
    outputClasses[key] = normalizeDraftItems(args[key], key, sourceReference);
  }

  const draft = {
    schema: "beai.knowledge_loop.codex_draft.v0_1",
    generated_at: nowIso(),
    mode: "codex-review-only-draft",
    status: "review-required-not-promoted",
    source_record: {
      id,
      title,
      project: args.project || "Codex workspace",
      source_type: args.source_type || "codex_work_session",
      source_reference: sourceReference,
      workspace
    },
    first_pass_note: {
      summary: args.summary || "",
      source_reference: sourceReference,
      review_status: "needs-human-review"
    },
    output_classes: outputClasses,
    review_status: {
      memory_status: "review-required-no-durable-write",
      package_status: "draft-candidate-or-not-applicable",
      release_state: "not-a-release-action",
      automation_status: "not-activated",
      external_action_status: "not-allowed-without-approval"
    },
    safety: safetyBoundary(),
    next_safe_action: args.next_safe_action || "Review this draft before any promotion, memory write, automation, connector action, or release wording."
  };

  const filePath = safeFilePath(draftDir, id, ".json", "draft file");
  fs.writeFileSync(filePath, `${JSON.stringify(draft, null, 2)}\n`, "utf8");
  appendReviewQueue(workspace, draft, filePath);
  return {
    status: "captured-draft",
    path: filePath,
    id,
    boundary: "draft written locally; no memory promotion or external action"
  };
}

function appendReviewQueue(workspace, draft, filePath) {
  const root = storeRoot(workspace);
  const queueDir = path.join(root, "review-queue");
  ensureDir(queueDir);
  const eventPath = path.join(queueDir, "queue.jsonl");
  const event = {
    at: nowIso(),
    id: draft.source_record.id,
    title: draft.source_record.title,
    source_reference: draft.source_record.source_reference,
    draft_path: filePath,
    status: "needs-review",
    next_safe_action: draft.next_safe_action
  };
  fs.appendFileSync(eventPath, `${JSON.stringify(event)}\n`, "utf8");
}

function reviewQueue(args = {}) {
  const workspace = resolveWorkspace(args);
  const queuePath = path.join(storeRoot(workspace), "review-queue", "queue.jsonl");
  if (!fs.existsSync(queuePath)) {
    return {
      workspace,
      queue_path: queuePath,
      count: 0,
      items: [],
      boundary: "review queue only; no promotion"
    };
  }
  const items = fs.readFileSync(queuePath, "utf8")
    .split(/\n/)
    .filter(Boolean)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .slice(-Math.max(1, Math.min(Number(args.limit || 25), 100)))
    .reverse();
  return {
    workspace,
    queue_path: queuePath,
    count: items.length,
    items,
    boundary: "review queue only; no durable memory promotion"
  };
}

function promotePlan(args = {}) {
  const workspace = resolveWorkspace(args);
  const id = String(args.id || "").trim();
  if (!id) throw new Error("id is required");
  const record = loadRecords(workspace).find((item) => item.id === id || item.path === id);
  if (!record) {
    return { found: false, id, workspace, message: "No matching draft or record found." };
  }
  const plan = {
    schema: "beai.knowledge_loop.promote_plan.v0_1",
    generated_at: nowIso(),
    status: "plan-only-approval-required",
    id: record.id,
    title: record.title,
    source_reference: record.source_reference,
    candidate_classes: recordClassCounts(record),
    proposed_actions: [
      "review source reference",
      "confirm facts and decisions are still valid",
      "remove rejected_scope or sensitive items",
      "choose target lane: session-continuity, project-knowledge, dev-asset, product-asset, or no-op",
      "only then create a separate approved promotion change"
    ],
    forbidden_actions: [
      "no durable memory write from this tool",
      "no Codex memory mutation",
      "no OpenClaw live config mutation",
      "no external send",
      "no release wording"
    ],
    safety: safetyBoundary()
  };
  const planDir = path.join(storeRoot(workspace), "review-queue");
  ensureDir(planDir);
  const planPath = safeFilePath(planDir, `${record.id}-promote-plan`, ".json", "promote plan file");
  fs.writeFileSync(planPath, `${JSON.stringify(plan, null, 2)}\n`, "utf8");
  return {
    status: "promote-plan-written",
    path: planPath,
    plan,
    boundary: "plan only; promotion still requires human approval"
  };
}

function evaluateRetrieval(args = {}) {
  const workspace = resolveWorkspace(args);
  const evalPath = path.resolve(args.eval_path || path.join(workspace, "eval", "retrieval-eval.json"));
  const allowedEvalRoots = [
    path.resolve(workspace, "eval"),
    path.resolve(SERVER_ROOT, "eval")
  ];
  if (!allowedEvalRoots.some((root) => isInside(root, evalPath))) {
    throw new Error("Unsafe eval_path: retrieval eval files must be inside the workspace eval directory or the plugin eval directory.");
  }
  const evalSpec = readJsonIfValid(evalPath);
  if (!evalSpec || !Array.isArray(evalSpec.queries)) {
    throw new Error(`Invalid retrieval eval file: ${evalPath}`);
  }
  const results = evalSpec.queries.map((item) => {
    const search = searchKnowledge({ workspace, query: item.query, limit: item.limit || 5 });
    const top = search.results[0] || null;
    const passed = top?.id === item.expected_top;
    return {
      query: item.query,
      expected_top: item.expected_top,
      actual_top: top?.id || null,
      passed,
      top_score: top?.score || 0,
      reasons: top?.reasons || [],
      result_count: search.count
    };
  });
  const passed = results.filter((item) => item.passed).length;
  const report = {
    schema: "beai.knowledge_loop.retrieval_eval_report.v0_2",
    generated_at: nowIso(),
    workspace,
    eval_path: evalPath,
    total: results.length,
    passed,
    failed: results.length - passed,
    pass_rate: results.length ? passed / results.length : 0,
    results,
    boundary: "retrieval evaluation only; no memory promotion"
  };
  if (args.write === true) {
    const reportDir = path.join(storeRoot(workspace), "generated");
    ensureDir(reportDir);
    fs.writeFileSync(path.join(reportDir, "retrieval-eval-report.json"), `${JSON.stringify(report, null, 2)}\n`, "utf8");
  }
  return report;
}

function safetyBoundary() {
  return {
    memory_write_allowed: false,
    codex_memory_mutation_allowed: false,
    openclaw_live_config_mutation_allowed: false,
    cron_or_hook_allowed: false,
    external_send_allowed: false,
    release_packaging_allowed: false,
    requires_human_review: true
  };
}

function toolDefinitions() {
  return [
    {
      name: "knowledge.search",
      description: "Search local BEAI Knowledge Loop records in a Codex workspace. Read-only.",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string" },
          workspace: { type: "string" },
          limit: { type: "number" },
          include_states: { type: "array", items: { type: "string" } },
          exclude_states: { type: "array", items: { type: "string" } }
        },
        required: ["query"]
      }
    },
    {
      name: "knowledge.get_brief",
      description: "Return a concise source-grounded brief for a local knowledge record. Read-only.",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "string" },
          workspace: { type: "string" }
        },
        required: ["id"]
      }
    },
    {
      name: "knowledge.capture_draft",
      description: "Write a local review-only draft knowledge candidate. Does not promote memory.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          id: { type: "string" },
          title: { type: "string" },
          project: { type: "string" },
          source_reference: { type: "string" },
          summary: { type: "string" },
          observed_fact: { type: "array", items: { type: "string" } },
          user_decision: { type: "array", items: { type: "string" } },
          assistant_judgment: { type: "array", items: { type: "string" } },
          inferred_pattern: { type: "array", items: { type: "string" } },
          trap: { type: "array", items: { type: "string" } },
          knowledge_candidate: { type: "array", items: { type: "string" } },
          development_candidate: { type: "array", items: { type: "string" } },
          product_candidate: { type: "array", items: { type: "string" } },
          evidence: { type: "array", items: { type: "string" } },
          next_action: { type: "array", items: { type: "string" } },
          rejected_scope: { type: "array", items: { type: "string" } },
          next_safe_action: { type: "string" }
        },
        required: ["title", "summary", "source_reference"]
      }
    },
    {
      name: "knowledge.index",
      description: "Build or write a local retrieval index for BEAI Knowledge Loop records. No promotion.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          write: { type: "boolean" }
        }
      }
    },
    {
      name: "knowledge.set_review_state",
      description: "Write a local sidecar review state for a record. Does not mutate the original record or promote memory.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          id: { type: "string" },
          state: {
            type: "string",
            enum: REVIEW_STATES
          },
          reason: { type: "string" },
          reviewer: { type: "string" },
          supersedes: { type: "string" },
          superseded_by: { type: "string" }
        },
        required: ["id", "state"]
      }
    },
    {
      name: "knowledge.review_queue",
      description: "List review-only draft candidates waiting for human review.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          limit: { type: "number" }
        }
      }
    },
    {
      name: "knowledge.promote_plan",
      description: "Create a plan-only promotion review for a draft or record. Does not promote memory.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          id: { type: "string" }
        },
        required: ["id"]
      }
    },
    {
      name: "knowledge.evaluate",
      description: "Run a retrieval quality eval with expected top records. No promotion.",
      inputSchema: {
        type: "object",
        properties: {
          workspace: { type: "string" },
          eval_path: { type: "string" },
          write: { type: "boolean" }
        }
      }
    },
    {
      name: "knowledge.boundaries",
      description: "Return BEAI Knowledge Loop for Codex safety boundaries.",
      inputSchema: {
        type: "object",
        properties: {}
      }
    }
  ];
}

function contentJson(value) {
  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(value, null, 2)
      }
    ]
  };
}

async function handle(request) {
  const { method, id, params = {} } = request;
  if (method === "initialize") {
    return {
      jsonrpc: "2.0",
      id,
      result: {
        protocolVersion: params.protocolVersion || "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: {
          name: "beai-knowledge-loop-for-codex",
          version: SERVER_VERSION
        },
        instructions: "Read and draft only. Search source-grounded knowledge before Codex work; capture review-only drafts after work. Never promote durable memory, send externally, package releases, or activate automation."
      }
    };
  }
  if (method === "tools/list") {
    return { jsonrpc: "2.0", id, result: { tools: toolDefinitions() } };
  }
  if (method === "tools/call") {
    const name = params.name;
    const args = params.arguments || {};
    if (name === "knowledge.search") return { jsonrpc: "2.0", id, result: contentJson(searchKnowledge(args)) };
    if (name === "knowledge.get_brief") return { jsonrpc: "2.0", id, result: contentJson(getBrief(args)) };
    if (name === "knowledge.capture_draft") return { jsonrpc: "2.0", id, result: contentJson(captureDraft(args)) };
    if (name === "knowledge.index") return { jsonrpc: "2.0", id, result: contentJson(buildIndex(args)) };
    if (name === "knowledge.set_review_state") return { jsonrpc: "2.0", id, result: contentJson(setReviewState(args)) };
    if (name === "knowledge.review_queue") return { jsonrpc: "2.0", id, result: contentJson(reviewQueue(args)) };
    if (name === "knowledge.promote_plan") return { jsonrpc: "2.0", id, result: contentJson(promotePlan(args)) };
    if (name === "knowledge.evaluate") return { jsonrpc: "2.0", id, result: contentJson(evaluateRetrieval(args)) };
    if (name === "knowledge.boundaries") return { jsonrpc: "2.0", id, result: contentJson(safetyBoundary()) };
    throw new Error(`Unknown tool: ${name}`);
  }
  if (method === "notifications/initialized") return null;
  return {
    jsonrpc: "2.0",
    id,
    error: {
      code: -32601,
      message: `Method not found: ${method}`
    }
  };
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

rl.on("line", async (line) => {
  if (!line.trim()) return;
  let request;
  try {
    request = JSON.parse(line);
    const response = await handle(request);
    if (response) process.stdout.write(`${JSON.stringify(response)}\n`);
  } catch (error) {
    const id = request?.id ?? null;
    process.stdout.write(`${JSON.stringify({
      jsonrpc: "2.0",
      id,
      error: {
        code: -32000,
        message: error instanceof Error ? error.message : String(error)
      }
    })}\n`);
  }
});
