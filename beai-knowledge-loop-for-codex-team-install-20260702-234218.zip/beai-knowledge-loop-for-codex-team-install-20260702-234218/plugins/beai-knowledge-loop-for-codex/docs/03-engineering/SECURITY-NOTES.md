# Security Notes

BEAI Knowledge Loop for Codex is a local, review-first tool. Its security model is based on narrow local file boundaries and explicit human review before durable memory promotion.

## Required Boundaries

- Do not print or commit secrets.
- Do not send, publish, deploy, activate automation, handle payment, or mutate external accounts.
- Write only review-only drafts, indexes, eval reports, review queues, and review-state sidecars.
- Keep all Knowledge Loop writes inside the selected workspace store: `.codex/knowledge-loop`.
- Reject workspace roots that point at the filesystem root or the user's home root.
- Reject draft ids that contain path separators, traversal segments, or unsafe filename characters.
- Read retrieval eval files only from the workspace `eval/` directory or this plugin's own `eval/` directory.
- Verify installed plugin manifests from the actual plugin install root, not only from the source repository root.

## Production Hardening Checks

The production gate must include:

- path traversal rejection for `knowledge.capture_draft`
- promote-plan filename containment
- eval path containment
- package hygiene check
- install-root MCP path check
- smoke test in a temporary workspace, not in the source tree

The tool may write local review-only files, but it must never turn those files into approved durable memory without an explicit human review process outside this MCP server.
