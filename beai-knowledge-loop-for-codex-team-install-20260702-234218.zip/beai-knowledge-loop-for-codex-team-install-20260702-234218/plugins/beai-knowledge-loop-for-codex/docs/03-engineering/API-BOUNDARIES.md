# API Boundaries

## Local Read

- `knowledge.search`
- `knowledge.get_brief`
- `knowledge.review_queue`
- `knowledge.boundaries`

These tools read local workspace knowledge records, indexes, or review queues. They do not write durable memory.

## Local Review-Only Write

- `knowledge.capture_draft`
- `knowledge.index` with `write: true`
- `knowledge.set_review_state`
- `knowledge.promote_plan`
- `knowledge.evaluate` with `write: true`

These tools may write only inside the selected workspace store, normally `.codex/knowledge-loop`.

## Path Boundary

All workspace writes must stay under the resolved workspace store. User-provided draft ids are never trusted as file paths. Retrieval eval files may be read only from:

- `<workspace>/eval/`
- `<plugin-root>/eval/`

## Approval Boundary

This MCP server never performs:

- durable memory promotion
- Codex memory mutation
- OpenClaw live config mutation
- external sending or publishing
- release packaging or readiness claims
- cron, hook, or automation activation

Promotion plans are plans only. Human review is required before any approved memory or product change is made elsewhere.
