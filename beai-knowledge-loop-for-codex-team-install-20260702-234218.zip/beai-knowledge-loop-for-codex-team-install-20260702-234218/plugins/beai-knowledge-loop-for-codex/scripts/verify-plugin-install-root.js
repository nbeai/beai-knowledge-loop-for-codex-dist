#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function isInside(parent, child) {
  const relative = path.relative(parent, child);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function inspectConfig(config, pluginRoot, label) {
  const server = config?.mcpServers?.beaiKnowledgeLoop;
  if (!server) throw new Error(`${label}: missing mcpServers.beaiKnowledgeLoop`);
  if (server.command !== "node") throw new Error(`${label}: expected command=node`);
  const args = Array.isArray(server.args) ? server.args : [];
  if (args.length !== 1) throw new Error(`${label}: expected exactly one MCP server arg`);
  const mcpPath = args[0];
  if (mcpPath.includes("__RUN_INSTALL_COMMAND_FIRST__")) {
    throw new Error(`${label}: installer placeholder is still present`);
  }
  if (!path.isAbsolute(mcpPath)) {
    throw new Error(`${label}: MCP server path must be absolute after install`);
  }
  const resolved = path.resolve(mcpPath);
  if (!isInside(pluginRoot, resolved)) {
    throw new Error(`${label}: MCP server path escapes plugin install root`);
  }
  if (!fs.existsSync(resolved)) {
    throw new Error(`${label}: MCP server path does not exist: ${resolved}`);
  }
  return resolved;
}

const pluginRoot = path.resolve(process.argv[2] || path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."));
const pluginJsonPath = path.join(pluginRoot, ".codex-plugin", "plugin.json");
const mcpJsonPath = path.join(pluginRoot, ".mcp.json");

if (!fs.existsSync(pluginJsonPath)) throw new Error(`Missing plugin manifest: ${pluginJsonPath}`);
if (!fs.existsSync(mcpJsonPath)) throw new Error(`Missing MCP config: ${mcpJsonPath}`);

const pluginJson = readJson(pluginJsonPath);
const mcpJson = readJson(mcpJsonPath);
const pluginMcpPath = inspectConfig(pluginJson, pluginRoot, "plugin.json");
const mcpJsonPathResolved = inspectConfig(mcpJson, pluginRoot, ".mcp.json");

if (pluginMcpPath !== mcpJsonPathResolved) {
  throw new Error("plugin.json and .mcp.json point to different MCP server paths");
}

console.log(JSON.stringify({
  status: "passed",
  plugin_root: pluginRoot,
  mcp_server: pluginMcpPath
}, null, 2));
