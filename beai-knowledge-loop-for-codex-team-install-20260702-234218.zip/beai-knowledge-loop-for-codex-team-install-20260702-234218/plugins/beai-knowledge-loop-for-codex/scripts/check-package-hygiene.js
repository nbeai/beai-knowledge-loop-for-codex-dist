#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const forbiddenPatterns = [
  /\/\.beai-harness(?:\/|$)/,
  /\/\.codex\/knowledge-loop(?:\/|$)/,
  /\/review-queue(?:\/|$)/,
  /\/drafts(?:\/|$)/,
  /\/generated(?:\/|$)/
];

function usage() {
  console.error("Usage: node scripts/check-package-hygiene.js [archive.zip|directory]");
}

function normalize(entry) {
  return `/${String(entry || "").replace(/\\/g, "/")}`;
}

function listDirectory(root) {
  const entries = [];
  const walk = (dir) => {
    for (const name of fs.readdirSync(dir)) {
      const fullPath = path.join(dir, name);
      const relativePath = path.relative(root, fullPath);
      entries.push(relativePath);
      if (fs.statSync(fullPath).isDirectory()) walk(fullPath);
    }
  };
  walk(root);
  return entries;
}

function listZip(zipPath) {
  const result = spawnSync("zipinfo", ["-1", zipPath], { encoding: "utf8" });
  if (result.status !== 0) {
    throw new Error(result.stderr || `zipinfo failed for ${zipPath}`);
  }
  return result.stdout.split(/\n/).filter(Boolean);
}

const target = process.argv[2] || path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const targetPath = path.resolve(target);
if (!fs.existsSync(targetPath)) {
  throw new Error(`Package target not found: ${targetPath}`);
}

const entries = fs.statSync(targetPath).isDirectory() ? listDirectory(targetPath) : listZip(targetPath);
const violations = entries.filter((entry) => forbiddenPatterns.some((pattern) => pattern.test(normalize(entry))));

if (violations.length) {
  console.error(JSON.stringify({
    status: "failed",
    target: targetPath,
    violations
  }, null, 2));
  process.exit(1);
}

console.log(JSON.stringify({
  status: "passed",
  target: targetPath,
  checked_entries: entries.length,
  forbidden_patterns: forbiddenPatterns.map((pattern) => pattern.source)
}, null, 2));
