---
name: beai-knowledge-loop
description: Use when Codex work should search prior decisions, traps, or reusable project knowledge before acting, or capture review-only knowledge candidates after a session. Do not use for automatic memory writes, external sends, release claims, or live automation.
---

# BEAI Knowledge Loop for Codex

## Identity

BEAI Knowledge Loop for Codex is a review-first knowledge production workflow.

It helps Codex stop treating every session as a fresh start by searching prior source-grounded decisions before work and capturing draft knowledge candidates after work.

It is not a durable memory writer.

## Core Flow

```text
search prior knowledge
-> use source-grounded decisions and traps during work
-> capture observed facts, decisions, patterns, traps, and candidates
-> keep results in review-only draft state
-> require human approval before promotion
```

## When To Use

Use this skill when:

- the user asks for BEAI, Knowledge Loop, reusable decisions, project memory, work records, or Codex knowledge capture
- a Codex task would benefit from prior decisions, traps, package boundaries, or development candidates
- a session produces decisions, mistakes, reusable implementation patterns, product candidates, or safety boundaries
- the user asks whether Codex can become smarter across sessions without uncontrolled memory

## Do Not Use For

- automatic durable memory writes
- modifying Codex memory files directly
- external sending, publishing, or customer communication
- release readiness claims
- live deployment, account connection, payment, contract, or legal actions
- cron, hook, or automation activation

## Required Behavior

Before substantial work:

1. Search prior knowledge when the request contains a project, product, BEAI, package, memory, plugin, MCP, release, safety, or recurring workflow signal.
2. Separate source-grounded facts from inferences.
3. Treat traps and safety boundaries as constraints, not as optional notes.
4. If search finds nothing, say so briefly and continue normally.

After substantial work:

1. Capture only reusable items.
2. Classify each item as one of:
   - observed_fact
   - user_decision
   - assistant_judgment
   - inferred_pattern
   - trap
   - knowledge_candidate
   - development_candidate
   - product_candidate
   - evidence
   - next_action
   - rejected_scope
3. Preserve source references beside major claims.
4. Mark memory and promotion status as review-required.
5. Do not claim memory was updated.

## MCP Tools

Use the BEAI Knowledge Loop MCP tools when available:

- `knowledge.search`: find matching local knowledge records
- `knowledge.get_brief`: get a concise review card for one record
- `knowledge.capture_draft`: write a review-only draft candidate
- `knowledge.index`: build a local retrieval index
- `knowledge.set_review_state`: mark records as approved, needs-review, stale, superseded, or rejected through a local sidecar
- `knowledge.review_queue`: list drafts waiting for review
- `knowledge.promote_plan`: create a plan-only promotion review
- `knowledge.evaluate`: run a retrieval quality eval with expected top results
- `knowledge.boundaries`: inspect the safety boundary for v0.1

If the MCP server is unavailable, produce a manual review card in the response and do not claim it was stored.

## Output Shape

For user-facing reports, prefer:

- Current judgment
- Source-grounded facts
- Reusable decisions
- Traps or risks
- Knowledge candidates
- Development or product candidates
- Review needed
- Next safe action

## Safety Boundary

Allowed in v0.1.1:

- read local knowledge records
- search local index files
- produce review cards
- write local draft candidate JSON files
- build local retrieval indexes
- create review queue entries
- create promotion plans that do not promote memory
- run retrieval quality evaluations
- write review-state sidecars for local retrieval quality control

Not allowed in v0.1.1:

- durable memory promotion
- Codex memory mutation
- OpenClaw live config mutation
- external network fetch as part of the tool
- external send or publish
- release package or readiness claim
- cron, hook, or automation activation
- executing a promotion plan without explicit human approval
- mutating original knowledge records during review-state changes

## Completion Language

Allowed:

- "knowledge candidates captured as review-only drafts"
- "source-grounded brief prepared"
- "no memory was updated"
- "promotion requires review"

Not allowed:

- "remembered"
- "stored as durable memory"
- "ready for release"
- "automation enabled"
- "published"
