import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const pluginRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function makeWorkspace() {
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), "beai-knowledge-loop-scenario-"));
  const store = path.join(workspace, ".codex", "knowledge-loop");
  fs.mkdirSync(path.join(store, "records"), { recursive: true });
  fs.copyFileSync(
    path.join(pluginRoot, "examples", "sample-record.json"),
    path.join(store, "records", "sample-record.json")
  );
  const exampleRecords = path.join(pluginRoot, "examples", "records");
  for (const entry of fs.readdirSync(exampleRecords)) {
    if (entry.endsWith(".json")) {
      fs.copyFileSync(path.join(exampleRecords, entry), path.join(store, "records", entry));
    }
  }
  return { workspace, store };
}

function call(request, cwd = pluginRoot) {
  return new Promise((resolve, reject) => {
    const child = spawn("node", [path.join(pluginRoot, "mcp", "beai-knowledge-loop-mcp.js")], {
      cwd,
      stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`MCP exited ${code}: ${stderr}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout.trim()));
      } catch (error) {
        reject(new Error(`Invalid JSON response: ${stdout}\n${error}`));
      }
    });
    child.stdin.write(`${JSON.stringify(request)}\n`);
    child.stdin.end();
  });
}

async function tool(name, args = {}, id = 1) {
  const response = await call({
    jsonrpc: "2.0",
    id,
    method: "tools/call",
    params: { name, arguments: args }
  });
  assert.equal(response.jsonrpc, "2.0");
  assert.ok(response.result);
  return JSON.parse(response.result.content[0].text);
}

async function toolError(name, args = {}, id = 1) {
  const response = await call({
    jsonrpc: "2.0",
    id,
    method: "tools/call",
    params: { name, arguments: args }
  });
  assert.equal(response.jsonrpc, "2.0");
  assert.ok(response.error);
  return response.error;
}

test("Guided First Workflow first success path: index, search, brief, draft, queue, and promote plan work without promotion", async () => {
  const { workspace, store } = makeWorkspace();

  const index = await tool("knowledge.index", { workspace, write: true }, 10);
  assert.equal(index.record_count >= 6, true);
  assert.equal(fs.existsSync(path.join(store, "index.json")), true);
  assert.ok(index.records.some((record) => record.review_state.state === "needs-review"));

  const search = await tool("knowledge.search", { workspace, query: "Codex automatic memory writer", limit: 3 }, 11);
  assert.equal(search.results[0].id, "memory-pollution-boundary");
  assert.equal(search.results[0].score > 10, true);
  assert.ok(search.results[0].reasons.length > 0);

  const brief = await tool("knowledge.get_brief", { workspace, id: "sample-codex-knowledge-loop-001" }, 12);
  assert.equal(brief.found, true);
  assert.equal(brief.boundary, "brief only; no durable memory update");
  assert.ok(brief.traps.includes("Do not turn v0.1 into an automatic memory writer or external automation layer."));

  const draft = await tool("knowledge.capture_draft", {
    workspace,
    id: "scenario-success-draft",
    title: "Scenario Success Draft",
    summary: "Scenario first success path draft.",
    source_reference: "scenario-test",
    observed_fact: ["A draft can be captured after Codex work."],
    development_candidate: ["Review queue can expose pending drafts."]
  }, 13);
  assert.equal(draft.status, "captured-draft");

  const queue = await tool("knowledge.review_queue", { workspace, limit: 10 }, 14);
  assert.ok(queue.items.some((item) => item.id === "scenario-success-draft"));

  const plan = await tool("knowledge.promote_plan", { workspace, id: "scenario-success-draft" }, 15);
  assert.equal(plan.status, "promote-plan-written");
  assert.equal(plan.plan.safety.memory_write_allowed, false);
  assert.equal(plan.boundary, "plan only; promotion still requires human approval");

  const evaluation = await tool("knowledge.evaluate", {
    workspace,
    eval_path: path.join(pluginRoot, "eval", "retrieval-eval.json"),
    write: true
  }, 16);
  assert.equal(evaluation.total, 5);
  assert.equal(evaluation.failed, 0);
  assert.equal(evaluation.pass_rate, 1);
});

test("Guided First Workflow review state sidecar controls stale and rejected retrieval", async () => {
  const { workspace, store } = makeWorkspace();

  const stale = await tool("knowledge.set_review_state", {
    workspace,
    id: "memory-pollution-boundary",
    state: "stale",
    reason: "Scenario test makes this record stale without mutating source JSON.",
    reviewer: "scenario-test"
  }, 40);
  assert.equal(stale.status, "review-state-set");
  assert.equal(stale.state, "stale");
  assert.equal(fs.existsSync(path.join(store, "review-queue", "review-states.json")), true);

  const afterStale = await tool("knowledge.search", {
    workspace,
    query: "automatic memory writer",
    limit: 5
  }, 41);
  assert.notEqual(afterStale.results[0].id, "memory-pollution-boundary");
  assert.equal(afterStale.results.some((item) => item.id === "memory-pollution-boundary" && item.review_state.state === "stale"), true);

  const rejected = await tool("knowledge.set_review_state", {
    workspace,
    id: "approval-boundary-plugin-install",
    state: "rejected",
    reason: "Scenario test verifies default rejected exclusion.",
    reviewer: "scenario-test"
  }, 42);
  assert.equal(rejected.state, "rejected");

  const defaultSearch = await tool("knowledge.search", {
    workspace,
    query: "marketplace install approval required plugin sharing",
    limit: 5
  }, 43);
  assert.equal(defaultSearch.results.some((item) => item.id === "approval-boundary-plugin-install"), false);

  const includedSearch = await tool("knowledge.search", {
    workspace,
    query: "marketplace install approval required plugin sharing",
    include_states: ["rejected"],
    exclude_states: [],
    limit: 5
  }, 44);
  assert.equal(includedSearch.results.some((item) => item.id === "approval-boundary-plugin-install" && item.review_state.state === "rejected"), true);
});

test("Guided First Workflow empty state: search and review queue are useful before user data exists", async () => {
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), "beai-knowledge-loop-empty-"));

  const search = await tool("knowledge.search", { workspace, query: "anything" }, 20);
  assert.equal(search.count, 0);
  assert.equal(search.boundary, "read-only search; no memory write or promotion");

  const queue = await tool("knowledge.review_queue", { workspace }, 21);
  assert.equal(queue.count, 0);
  assert.equal(queue.boundary, "review queue only; no promotion");

  const boundaries = await tool("knowledge.boundaries", {}, 22);
  assert.equal(boundaries.memory_write_allowed, false);
  assert.equal(boundaries.requires_human_review, true);
});

test("Guided First Workflow failure or recovery state: missing brief and promote inputs recover safely", async () => {
  const { workspace } = makeWorkspace();

  const missingBrief = await tool("knowledge.get_brief", { workspace, id: "missing-record" }, 30);
  assert.equal(missingBrief.found, false);
  assert.match(missingBrief.message, /No matching knowledge record/);

  const missingPlan = await tool("knowledge.promote_plan", { workspace, id: "missing-record" }, 31);
  assert.equal(missingPlan.found, false);
  assert.match(missingPlan.message, /No matching draft or record/);
});

test("Production hardening: draft ids cannot escape the review-only draft directory", async () => {
  const { workspace, store } = makeWorkspace();
  const outsidePath = path.join(path.dirname(workspace), "outside-workspace.json");

  const error = await toolError("knowledge.capture_draft", {
    workspace,
    id: "../../../../outside-workspace",
    title: "Unsafe Draft",
    summary: "This should not be written.",
    source_reference: "path-hardening-test"
  }, 50);

  assert.match(error.message, /Unsafe id/);
  assert.equal(fs.existsSync(outsidePath), false);
  assert.equal(fs.existsSync(path.join(store, "drafts", "..", "..", "outside-workspace.json")), false);
});

test("Production hardening: retrieval eval paths stay inside approved eval roots", async () => {
  const { workspace } = makeWorkspace();
  const externalEval = path.join(os.tmpdir(), `beai-external-eval-${Date.now()}.json`);
  fs.writeFileSync(externalEval, JSON.stringify({ queries: [] }), "utf8");

  const error = await toolError("knowledge.evaluate", {
    workspace,
    eval_path: externalEval,
    write: false
  }, 51);

  assert.match(error.message, /Unsafe eval_path/);
});
