#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const [pluginJsonPath, mcpJsonPath, mcpServerPath] = process.argv.slice(2);

if (!pluginJsonPath || !mcpJsonPath || !mcpServerPath) {
  console.error("Usage: node tools/patch-mcp-paths.mjs <plugin.json> <.mcp.json> <mcp-server.js>");
  process.exit(2);
}

const absoluteMcpServer = path.resolve(mcpServerPath);

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`);
}

function patchMcpConfig(config) {
  config.mcpServers ??= {};
  config.mcpServers.beaiKnowledgeLoop ??= {};
  config.mcpServers.beaiKnowledgeLoop.command = "node";
  config.mcpServers.beaiKnowledgeLoop.args = [absoluteMcpServer];
  config.mcpServers.beaiKnowledgeLoop.startup_timeout_sec = 10;
  config.mcpServers.beaiKnowledgeLoop.tool_timeout_sec = 30;
  config.mcpServers.beaiKnowledgeLoop.enabled = true;
  config.mcpServers.beaiKnowledgeLoop.default_tools_approval_mode = "auto";
  return config;
}

const pluginJson = patchMcpConfig(readJson(pluginJsonPath));
const mcpJson = patchMcpConfig(readJson(mcpJsonPath));

writeJson(pluginJsonPath, pluginJson);
writeJson(mcpJsonPath, mcpJson);

console.log(JSON.stringify({
  status: "patched",
  mcp_server: absoluteMcpServer,
  files: [pluginJsonPath, mcpJsonPath]
}, null, 2));

