# Safety Boundary

BEAI Knowledge Loop for Codex v0.3은 read + draft + review-state-control 제품이다.

## 허용

- 로컬 지식 기록 읽기
- 로컬 검색
- review card 생성
- draft candidate 파일 생성
- retrieval index 생성
- review queue 기록
- promotion plan 생성
- review state sidecar 기록
- stale, superseded, rejected 상태 기반 검색 오염 제어

## 자동화 원칙

BEAI Knowledge Loop의 기본 자동화 원칙은 `Auto-capture, not auto-approve`다.

자동화해도 되는 것은 작업 전 검색, 작업 중 brief 조회, 작업 후 review-only draft 기록이다.

자동화하면 안 되는 것은 사람 승인 없는 durable memory promotion, `approved` 승격, 외부 실행, 고객 접촉, 공개 게시, 배포, 계정/돈/계약/법률 관련 행동이다.

상세 기준은 `docs/02-workflow/AUTO-CAPTURE-NOT-AUTO-APPROVE-ko.md`를 따른다.

## 금지

- Codex memory 직접 수정
- durable memory promotion
- 외부 발송
- 고객 응대
- 계정 연결
- 결제, 계약, 법률 판단
- 공개 게시
- release readiness claim
- cron, hook, automation activation
- promotion plan 실행
- 원본 지식 기록을 상태 변경 과정에서 직접 수정

## 이유

지식 루프의 목표는 더 많이 저장하는 것이 아니라, 틀리게 저장하지 않는 것이다.

작업 기록은 다음 단계를 거쳐야 한다.

```text
draft
-> review
-> approval
-> promotion
```

v0.3은 draft, promotion plan, review-state sidecar까지만 담당한다.

`promote_plan`은 승격 실행이 아니라 검토 계획이다.

`set_review_state`는 원본 기록을 수정하지 않고 `.codex/knowledge-loop/review-queue/review-states.json`에 별도 상태를 남긴다.
