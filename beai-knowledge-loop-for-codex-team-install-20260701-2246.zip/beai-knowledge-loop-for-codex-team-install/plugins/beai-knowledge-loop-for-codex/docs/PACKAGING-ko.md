# BEAI Knowledge Loop for Codex Packaging Notes

## 정식 상품명

BEAI Knowledge Loop for Codex

## 한국어 설명명

코덱스용 비아이 지식 루프

## 현재 패키지 상태

현재 상태는 공개 배포판이 아니라 local product candidate다.

검증된 것:

- Codex plugin scaffold
- Skill
- MCP server
- local marketplace 설치
- Codex plugin cache 설치
- MCP tools/list 응답
- npm verify
- review state sidecar
- stale/rejected 검색 오염 제어

아직 보류인 것:

- 공개 marketplace 배포
- 외부 공유
- 고객 대상 안내
- 유료 판매
- durable memory promotion
- hook/cron 자동화
- 외부 계정/서비스 연결

## 패키징 원칙

1. 개발 원본과 설치 후보를 분리한다.
2. 설치 후보에는 BEAI Harness 내부 작업 기록을 넣지 않는다.
3. 제품 설명은 memory writer가 아니라 review-first knowledge loop로 유지한다.
4. release readiness claim은 하지 않는다.
5. 개인/로컬 사용 후보와 공개 배포 후보를 분리한다.

## 포함 파일

설치 후보에 포함:

- `.codex-plugin/plugin.json`
- `.mcp.json`
- `skills/`
- `mcp/`
- `scripts/`
- `docs/`
- `examples/`
- `eval/`
- `test/`
- `package.json`
- `AGENTS.md`
- `workspace-notes/`

설치 후보에서 제외:

- `.beai-harness/`
- 로컬 cache
- 개인 계정 정보
- 외부 공개용 약속 문구
- 고객/계약/법률 관련 원문

## 팀 설치 marketplace 후보

팀 설치 zip은 다음 구조를 가진다.

```text
beai-knowledge-loop-for-codex-team-install/
  .agents/plugins/marketplace.json
  plugins/beai-knowledge-loop-for-codex/
  설치.command
  README-TEAM-INSTALL-ko.md
```

팀 설치용 marketplace name:

```text
beai-team-local
```

팀 설치용 plugin:

```text
beai-knowledge-loop-for-codex@beai-team-local
```

팀원은 zip을 푼 뒤 `설치.command`를 실행한다. 설치 스크립트는 팀원 컴퓨터의 실제 폴더 위치에 맞춰 MCP server 경로를 보정하고, 해당 폴더를 Codex local marketplace로 등록한다.

주의:

- zip 생성 전 원본 workspace에서는 `npm run verify`를 돌릴 수 있다.
- 설치 후보 staging에서는 테스트를 돌리지 않는다.
- 테스트를 돌리면 `.codex/knowledge-loop` generated store가 생길 수 있으므로 archive 오염 가능성이 생긴다.

## 다음 승격 조건

개인 기본 marketplace 또는 공개 후보로 옮기기 전에 다음을 확인한다.

1. 새 Codex 스레드에서 skill과 MCP가 자연스럽게 로드되는가
2. 실제 작업 전 `knowledge.search`가 유용한 결과를 주는가
3. 실제 작업 후 `knowledge.capture_draft`가 과잉 저장 없이 필요한 후보만 남기는가
4. `stale`, `rejected`, `superseded` 기준이 윤의 판단 방식과 맞는가
5. 외부 공개 없이도 윤의 반복 작업 품질이 올라가는가
