# Local Install Notes

이 폴더는 Codex 플러그인 후보 구조다.

현재 상태:

- local product candidate
- plugin scaffold present
- skill present
- MCP server present
- release local marketplace install performed
- app restart callable exposure verified

## 검토 후 설치 후보

Codex 플러그인으로 설치하려면 이 폴더를 Codex marketplace 또는 개인 플러그인 경로에 연결한다.

현재 설치 후보:

```text
beai-knowledge-loop-for-codex@beai-release-local
0.1.0+codex.20260701111445
```

확인된 것:

- `codex plugin list`에서 release local plugin installed/enabled
- `codex mcp list`에서 plugin-bundled `beaiKnowledgeLoop` enabled
- 설치 cache `npm run verify` 통과
- MCP `initialize -> tools/list` 직접 호출 통과
- Codex 앱 재시작 후 `mcp__beaiKnowledgeLoop.knowledge_search` callable 실행 통과
- Codex 앱 재시작 후 `mcp__beaiKnowledgeLoop.knowledge_get_brief` callable 실행 통과
- archive `zip -T` 통과
- package hygiene 통과

아직 남은 것:

- workspace 공유
- 공개 배포
- 자동화 등록

현재 운영 후보는 plugin-bundled `beaiKnowledgeLoop` 단일 경로다.

## 로컬 store 초기화

```bash
node scripts/init-knowledge-loop-store.js /path/to/workspace
```

## MCP smoke test

```bash
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | node mcp/beai-knowledge-loop-mcp.js
```

Codex식 초기화 순서 확인:

```bash
printf '%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"codex-debug","version":"local"}}}' \
  '{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}' \
  | node mcp/beai-knowledge-loop-mcp.js
```

Codex 앱에서 callable 도구가 보이지 않으면 앱을 재시작하거나 완전히 fresh session을 연 뒤 다시 확인한다. 설치 직후 이미 실행 중인 thread에서는 새 MCP tool이 model-visible callable layer에 바로 올라오지 않을 수 있다.

## 로컬 검증

```bash
npm run check
npm test
npm run verify
npm run eval
```

## v0.3 상태 제어 확인

`knowledge.set_review_state`는 원본 기록을 직접 수정하지 않고 다음 파일에 상태를 남긴다.

```text
.codex/knowledge-loop/review-queue/review-states.json
```

기본 검색은 `rejected` 상태를 제외한다. `stale`과 `superseded`는 검색 점수가 크게 낮아진다. 감사나 회고 목적으로 보려면 `include_states`와 `exclude_states`를 명시한다.
