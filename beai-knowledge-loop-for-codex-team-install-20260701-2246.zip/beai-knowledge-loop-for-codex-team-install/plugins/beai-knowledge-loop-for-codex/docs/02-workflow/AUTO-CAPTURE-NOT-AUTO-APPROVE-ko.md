# Auto-Capture, Not Auto-Approve

## 한 줄 원칙

BEAI Knowledge Loop는 자동 기록을 강하게 허용하되, 자동 승인은 허용하지 않는다.

> Auto-capture, not auto-approve.

## 왜 이 원칙이 필요한가

Knowledge Loop의 상품성은 사용자가 매번 기억하라고 지시하지 않아도, AI가 작업 흐름 속에서 필요한 과거 판단을 찾고 작업 후 기록 후보를 남기는 데 있다.

승인창이 매번 뜨면 사용감이 끊긴다. 특히 `knowledge.search`, `knowledge.get_brief`, `knowledge.capture_draft` 같은 로컬 review-only 도구는 실제 위험보다 마찰이 크다.

하지만 모든 것을 자동화하면 안 된다. AI가 초안을 남기는 것과 회사 지식으로 승인하는 것은 다르다. 이 제품의 신뢰는 그 차이를 지키는 데서 나온다.

## 자동화 3단계

### 1. 완전 자동 허용

다음 기능은 기본적으로 자동 허용해도 된다.

- `knowledge.search`
- `knowledge.get_brief`
- `knowledge.capture_draft`
- `knowledge.index`
- `knowledge.review_queue`
- `knowledge.evaluate`
- `knowledge.boundaries`

이 기능들은 로컬 지식 검색, 요약, 초안 기록, 평가, 경계 확인에 해당한다. 외부 발송, 공개 게시, 결제, 고객 응대, durable memory 승격을 하지 않는다.

사용자 언어:

> AI가 일할 때 필요한 업무일지를 찾아보고, 일이 끝나면 인수인계 초안을 남긴다.

### 2. 조건부 자동 허용

다음 기능은 상황에 따라 자동화할 수 있지만, 상태 변경의 의미를 제한해야 한다.

- `knowledge.promote_plan`
- `knowledge.set_review_state`

`knowledge.promote_plan`은 승격 실행이 아니라 검토 계획이므로 자동 생성할 수 있다.

`knowledge.set_review_state`는 상태를 바꾸므로 더 조심해야 한다.

허용 가능한 자동 상태:

- `needs-review`
- `stale` 제안
- `superseded` 제안

윤의 명시 승인이 필요한 상태:

- `approved`
- `rejected`

사용자 언어:

> AI가 "이 기록은 검토가 필요합니다" 또는 "이전 판단일 수 있습니다"라고 분류하는 것은 가능하지만, 회사 기준으로 채택하거나 폐기하는 것은 대표가 결정한다.

### 3. 자동화 금지

다음 행동은 풀오토로 열지 않는다.

- durable memory promotion
- Codex memory 직접 수정
- OpenClaw live config 변경
- 고객 응대
- 외부 발송
- 공개 게시
- 결제, 계약, 법률 판단
- 계정 연결
- 배포 또는 release readiness claim
- cron, hook, 상시 백그라운드 자동 실행
- promotion plan 실행

사용자 언어:

> AI 직원이 업무일지 초안을 쓰는 것은 자동화할 수 있지만, 대표 결재 없이 회사 밖으로 나가거나 회사 기준으로 확정되면 안 된다.

## 제품 사용감 기준

좋은 사용감:

- 작업 시작 전 자동으로 과거 판단을 찾는다.
- 작업 중 관련 함정과 기준을 조용히 반영한다.
- 작업 후 reusable한 판단만 review-only 초안으로 남긴다.
- 사용자는 나중에 review queue에서 필요한 것만 승인한다.

나쁜 사용감:

- 모든 검색과 초안 기록마다 승인창이 뜬다.
- AI가 확인 없이 지식을 approved로 올린다.
- 사용자가 모르는 사이 외부 발송, 공개 게시, 배포, 계정 변경이 일어난다.
- 오래된 판단이 승인 상태로 계속 재사용된다.

## 권장 기본 정책

로컬 단독 사용자의 기본 정책:

- search/brief/capture는 항상 허용
- index/evaluate/review_queue는 항상 허용
- promote_plan은 허용
- set_review_state는 approved/rejected일 때 사용자 확인
- 외부 실행과 durable memory promotion은 항상 사용자 확인

팀/고객 환경의 기본 정책:

- search/brief는 허용
- capture_draft는 민감정보 필터 후 허용
- approved/rejected는 역할 권한 필요
- 외부 발송, 고객 응대, 공개 게시, 계정/결제/계약 관련 작업은 관리자 승인 필요

## 상품성 판단

이 원칙은 상품성을 올린다.

이유는 세 가지다.

1. AI가 실제 직원처럼 작업 전후 맥락을 챙기므로 체감 지능이 올라간다.
2. 매번 승인창을 누르는 마찰이 줄어든다.
3. 자동 승인과 외부 실행을 막기 때문에 신뢰 경계가 유지된다.

핵심 판매 문장:

> AI가 알아서 기억하는 시스템이 아니라, AI가 일한 흔적을 남기고 사람이 승인하는 시스템이다.

## 다음 개발 후보

- Tool별 자동화 등급 메타데이터 추가
- `capture_draft` 기본 자동 허용 안내 문구 추가
- `approved` 상태 변경 전 사용자 확인 체크 추가
- review queue에서 승인/폐기/보류를 쉽게 처리하는 콘솔 또는 화면 추가
- 민감정보 감지 후 capture_draft에 경고를 붙이는 기능 추가
