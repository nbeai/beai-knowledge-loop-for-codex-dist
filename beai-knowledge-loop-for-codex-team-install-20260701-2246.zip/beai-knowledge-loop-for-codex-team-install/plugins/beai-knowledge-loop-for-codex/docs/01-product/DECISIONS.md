# Decisions

Record user-approved decisions here.

## 2026-07-01: Auto-capture, not auto-approve

윤은 Knowledge Loop의 상품성을 높이기 위해 로컬 review-only 도구의 강한 자동화 방향을 승인했다.

결정:

- `knowledge.search`, `knowledge.get_brief`, `knowledge.capture_draft` 같은 로컬 read/draft 도구는 자동화 친화적으로 설계한다.
- 작업 후 reusable한 판단 후보를 review-only draft로 남기는 것은 풀오토에 가깝게 허용한다.
- `approved` 승격, durable memory promotion, 외부 발송, 공개 게시, 고객 응대, 돈/계약/법률/계정/배포 관련 행동은 자동화하지 않는다.

핵심 문장:

> Auto-capture, not auto-approve.

근거 문서:

- `docs/02-workflow/AUTO-CAPTURE-NOT-AUTO-APPROVE-ko.md`
