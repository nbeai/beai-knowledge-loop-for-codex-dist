# BEAI Knowledge Loop for Codex v0.3 Product Brief

## 한 줄 정의

BEAI Knowledge Loop for Codex는 Codex 작업에서 나온 결정, 근거, 실패, 함정, 제품화 후보를 검토 가능한 지식 후보로 남기고 다음 작업에서 다시 검색하게 만드는 Codex용 지식 루프 플러그인이다.

## 왜 필요한가

AI 코딩 에이전트는 코드를 고치고 테스트를 실행하는 능력은 빠르게 좋아지고 있다. 하지만 작업이 끝난 뒤 왜 그런 판단을 했는지, 어떤 함정을 피해야 하는지, 무엇이 다음 작업에 다시 쓸 자산인지가 흘러가기 쉽다.

이 플러그인의 목표는 Codex가 더 많은 것을 자동 기억하게 만드는 것이 아니라, Codex 작업의 판단 자산을 검토 가능한 형태로 남기는 것이다.

## v0.3 제품 경계

포함:

- 작업 전 로컬 지식 검색
- 로컬 검색 인덱스 생성
- review state sidecar 생성
- approved, needs-review, stale, superseded, rejected 상태 기반 검색 제어
- source-grounded brief 조회
- 작업 후 review-only draft capture
- review queue 조회
- promotion plan 생성
- retrieval quality eval 실행
- observed fact, decision, inference, trap, candidate 분리
- 안전 경계 표시

제외:

- durable memory write
- Codex memory 직접 수정
- 외부 발송
- 공개 게시
- release readiness claim
- cron, hook, automation activation
- 고객, 돈, 계정, 계약 관련 자동 처리

## 첫 사용자

- Codex를 반복적으로 쓰는 개발자
- BEAI/OpenClaw/nbeai 개발 작업을 이어가는 윤
- AI 작업 결과를 운영 지식으로 남기고 싶은 1인 기업가/사장 시장의 고급 사용자

## 첫 성공 테스트

1. 샘플 지식 기록을 검색할 수 있다.
2. 한 기록의 brief를 조회할 수 있다.
3. 작업 후 draft candidate를 생성하되 memory promotion은 하지 않는다.
4. draft candidate가 review queue에 들어간다.
5. promotion plan은 만들 수 있지만 실제 promotion은 하지 않는다.
6. 검색 평가셋에서 expected top result를 맞춘다.
7. stale 지식은 상위 검색에서 밀려난다.
8. rejected 지식은 기본 검색에서 제외되고 명시 검토 시에만 보인다.

## 제품 문장

개발자용:

> Codex가 코드를 고치는 데서 끝나지 않고, 프로젝트의 판단 자산을 축적하게 만든다.

사장 시장용:

> AI 직원이 일하고 나면 결과물만 남기는 게 아니라, 회사의 업무 지식도 남긴다.
