# Next Review

## Next Safe Action

Use plugin-bundled `mcp__beaiKnowledgeLoop` for read-only search and brief before future Codex Knowledge Loop work. Keep writes to review-only drafts unless 윤 explicitly approves promotion or external action.

## Review Before Continuing

- Check whether the current phase has pass/blocked evidence.
- Confirm that AI/developer scenario verification happened before final user review.
- Keep risky actions manual or dry-run until explicitly approved.
- Treat MCP registration and callable tool injection as verified after the Codex app restart check.
- Keep public release, customer messaging, durable memory promotion, and automation activation on hold.

## Session Resume

- `beai-local` old plugin was removed to avoid duplicate MCP server-name collision.
- `beai-release-local` is installed/enabled at `0.1.0+codex.20260701111445`.
- Plugin-bundled `beaiKnowledgeLoop` appears in `codex mcp list`.
- A temporary diagnostic MCP path was used during local verification and then removed.
- After Codex app restart, `mcp__beaiKnowledgeLoop.knowledge_search` and `knowledge_get_brief` became callable and succeeded.
- The current lesson is that plugin/MCP install changes need an app restart or fresh session before model-visible callable tools can be trusted.

## Recent Evidence

- verify: Executed 2 checks.
- closeout: Closeout decision: ready.
- closeout: Closeout decision: ready.
- verify: Executed 2 checks.
- closeout: Closeout decision: ready.
- app-restart-check: plugin-bundled `mcp__beaiKnowledgeLoop` became model-visible and read-only calls succeeded.
- knowledge-loop: captured review-only draft `session-20260701-app-restart-mcp-callable-success`.
- mcp: removed the temporary diagnostic MCP path after plugin-bundled path succeeded.
