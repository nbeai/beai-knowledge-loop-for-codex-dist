#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";

const workspace = path.resolve(process.argv[2] || process.cwd());
const root = path.join(workspace, ".codex", "knowledge-loop");
const dirs = ["records", "generated", "drafts", "review-queue"];

for (const dir of dirs) {
  fs.mkdirSync(path.join(root, dir), { recursive: true });
}

const readmePath = path.join(root, "README.md");
if (!fs.existsSync(readmePath)) {
  fs.writeFileSync(readmePath, `# BEAI Knowledge Loop Store

This local store is used by BEAI Knowledge Loop for Codex.

Allowed in v0.1:

- read local records
- search records
- create review-only drafts

Not allowed in v0.1:

- durable memory writes
- external sends
- release claims
- cron or hook activation

`, "utf8");
}

const exampleRecordsDir = path.resolve(new URL("../examples/records", import.meta.url).pathname);
if (fs.existsSync(exampleRecordsDir)) {
  for (const entry of fs.readdirSync(exampleRecordsDir)) {
    if (!entry.endsWith(".json")) continue;
    const source = path.join(exampleRecordsDir, entry);
    const target = path.join(root, "records", entry);
    if (!fs.existsSync(target)) fs.copyFileSync(source, target);
  }
}

console.log(JSON.stringify({
  workspace,
  store: root,
  created: dirs.map((dir) => path.join(root, dir))
}, null, 2));
