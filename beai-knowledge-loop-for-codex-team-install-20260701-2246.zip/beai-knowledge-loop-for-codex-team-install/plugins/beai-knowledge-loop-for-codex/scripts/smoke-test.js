#!/usr/bin/env node

import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";

const root = path.resolve(new URL("..", import.meta.url).pathname);
const workspace = root;
const store = path.join(workspace, ".codex", "knowledge-loop");
const records = path.join(store, "records");
fs.mkdirSync(records, { recursive: true });
fs.copyFileSync(path.join(root, "examples", "sample-record.json"), path.join(records, "sample-record.json"));
const exampleRecords = path.join(root, "examples", "records");
for (const entry of fs.readdirSync(exampleRecords)) {
  if (entry.endsWith(".json")) fs.copyFileSync(path.join(exampleRecords, entry), path.join(records, entry));
}

function call(request) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(root, "mcp", "beai-knowledge-loop-mcp.js")], {
      cwd: root,
      stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`MCP exited ${code}: ${stderr}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout.trim()));
      } catch (error) {
        reject(new Error(`Invalid JSON response: ${stdout}\n${error}`));
      }
    });
    child.stdin.write(`${JSON.stringify(request)}\n`);
    child.stdin.end();
  });
}

function tool(name, args = {}, id = 1) {
  return call({
    jsonrpc: "2.0",
    id,
    method: "tools/call",
    params: {
      name,
      arguments: args
    }
  });
}

function parseContent(response) {
  assert.equal(response.jsonrpc, "2.0");
  assert.ok(response.result);
  return JSON.parse(response.result.content[0].text);
}

const tools = await call({ jsonrpc: "2.0", id: 1, method: "tools/list", params: {} });
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.search"));
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.index"));
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.set_review_state"));
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.review_queue"));
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.promote_plan"));
assert.ok(tools.result.tools.some((item) => item.name === "knowledge.evaluate"));

const index = parseContent(await tool("knowledge.index", { workspace, write: true }, 2));
assert.equal(index.record_count >= 6, true);
assert.equal(fs.existsSync(path.join(store, "index.json")), true);

const search = parseContent(await tool("knowledge.search", { workspace, query: "automatic memory writer", limit: 5 }, 3));
assert.equal(search.count >= 1, true);
assert.equal(search.results[0].id, "memory-pollution-boundary");
assert.equal(search.results[0].score > 1, true);

const staleState = parseContent(await tool("knowledge.set_review_state", {
  workspace,
  id: "memory-pollution-boundary",
  state: "stale",
  reason: "Smoke test validates stale knowledge demotion.",
  reviewer: "smoke-test"
}, 31));
assert.equal(staleState.status, "review-state-set");
assert.equal(staleState.state, "stale");

const staleSearch = parseContent(await tool("knowledge.search", { workspace, query: "automatic memory writer", limit: 5 }, 32));
assert.notEqual(staleSearch.results[0].id, "memory-pollution-boundary");

const resetState = parseContent(await tool("knowledge.set_review_state", {
  workspace,
  id: "memory-pollution-boundary",
  state: "needs-review",
  reason: "Smoke test reset before retrieval eval.",
  reviewer: "smoke-test"
}, 33));
assert.equal(resetState.state, "needs-review");

const draft = parseContent(await tool("knowledge.capture_draft", {
  workspace,
  id: "smoke-review-draft",
  title: "Smoke Review Draft",
  summary: "Smoke test review queue draft.",
  source_reference: "smoke-test",
  observed_fact: ["Smoke test created a review draft."],
  trap: ["Draft capture must not promote memory."]
}, 4));
assert.equal(draft.status, "captured-draft");

const queue = parseContent(await tool("knowledge.review_queue", { workspace, limit: 5 }, 5));
assert.equal(queue.count >= 1, true);
assert.ok(queue.items.some((item) => item.id === "smoke-review-draft"));

const plan = parseContent(await tool("knowledge.promote_plan", { workspace, id: "smoke-review-draft" }, 6));
assert.equal(plan.status, "promote-plan-written");
assert.equal(plan.plan.status, "plan-only-approval-required");
assert.equal(plan.plan.safety.memory_write_allowed, false);

const boundaries = parseContent(await tool("knowledge.boundaries", {}, 7));
assert.equal(boundaries.memory_write_allowed, false);
assert.equal(boundaries.external_send_allowed, false);

const evaluation = parseContent(await tool("knowledge.evaluate", {
  workspace,
  eval_path: path.join(root, "eval", "retrieval-eval.json"),
  write: true
}, 8));
assert.equal(evaluation.total, 5);
assert.equal(evaluation.failed, 0);
assert.equal(evaluation.pass_rate, 1);

console.log(JSON.stringify({
  status: "passed",
  checks: [
    "tools/list",
    "knowledge.index",
    "weighted knowledge.search",
    "knowledge.set_review_state",
    "stale knowledge demotion",
    "knowledge.capture_draft",
    "knowledge.review_queue",
    "knowledge.promote_plan",
    "knowledge.evaluate",
    "knowledge.boundaries"
  ],
  workspace
}, null, 2));
